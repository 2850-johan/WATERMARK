#include <iostream>
using namespace std;

// Fonction pour convertir un nombre décimal en binaire

void decimalToBinary(int arr [], int size) {
     /*int size = 4;*/ // Taille du tableau

    int array_binary[8]; // Tableau pour stocker le résultat binaire (32 bits max)


    cout << "Tableau en binaire \n"  ;

    // Conversion de chaque valeur décimale en binaire
    for (int i = 0; i < size; i++) {
        int num = arr[i]; // Nombre actuel à convertir
        int index = 0;

        // Conversion en binaire
        while (num > 0) {
            array_binary[index] = num % 2; // Récupérer le bit de poids faible
            num /= 2;                      // Diviser par 2
            index++;
        }


        // Affichage du résultat en ordre inverse
        cout << "Valeur " << arr[i] << " en binaire : ";
        for (int j = index - 1; j >= 0; j--) {
            cout << array_binary[j];
        }
        cout << endl;
    }
}



/*int main() 
{
     int arr[] = {1,10,45,569,70} ;
    int size = sizeof(arr) / sizeof(arr[0]);
    decimalToBinary( arr , size); // Appeler la fonction
    return 0;
}
